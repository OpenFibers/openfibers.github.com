//
//  AAA.h
//  ipv6
//
//  Created by openthread on 6/20/16.
//  Copyright © 2016 openthread. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IPv6Tester : NSObject

- (void)test;

@end
