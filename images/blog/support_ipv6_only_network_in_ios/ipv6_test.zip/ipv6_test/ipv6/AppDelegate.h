//
//  AppDelegate.h
//  ipv6
//
//  Created by openthread on 6/20/16.
//  Copyright © 2016 openthread. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

